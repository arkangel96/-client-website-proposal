
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();

  const menuItems = [
    {
      title: 'HOME',
      href: '/',
      subItems: []
    },
    {
      title: 'ABOUT US',
      href: '/about',
      subItems: [
        { title: 'Overview', href: '/about-overview' },
        { title: 'Values', href: '/about-values' },
        { title: 'CEO Message', href: '/about-ceo-message' },
        { title: 'History', href: '/about-history' },
        { title: 'Business Permits', href: '/about-business-permits' },
        { title: 'Location', href: '/about-location' }
      ]
    },
    {
      title: 'SERVICES',
      href: '/key-services',
      subItems: [
        { title: 'Engineering', href: '/key-services-engineering' },
        { title: 'Procurement', href: '/key-services-procurement' },
        { title: 'Construction', href: '/key-services-construction' },
        { title: 'Commissioning', href: '/key-services-commissioning' },
        { title: 'Project Management', href: '/key-services-project-management' },
        { title: 'Technical Consulting', href: '/key-services-technical-consulting' }
      ]
    },
    {
      title: 'PROJECT EXPERIENCE',
      href: '/businesses',
      subItems: [
        { title: 'Petrochemical', href: '/businesses-petrochemical' },
        { title: 'Refinery', href: '/businesses-refinery' },
        { title: 'Power Generation', href: '/businesses-power-generation' }
      ]
    },
    {
      title: 'SUSTAINABILITY',
      href: '/sustainability',
      subItems: [
        { title: 'Quality Management', href: '/sustainability-quality-management' },
        { title: 'Environmental Management', href: '/sustainability-environmental-management' },
        { title: 'Safety/Health Management', href: '/sustainability-safety-health-management' },
        { title: 'Ethics/Compliance Management', href: '/sustainability-ethics-compliance-management' },
        { title: 'Ethics/Compliance Report Center', href: '/sustainability-ethics-compliance-report-center' },
        { title: 'Security Policy', href: '/sustainability-security-policy' },
        { title: 'New Business Partner Registration', href: '/sustainability-new-business-partner-registration' }
      ]
    },
    {
      title: 'RECRUITMENT',
      href: '/recruitment',
      subItems: [
        { title: 'Ideal Talent', href: '/recruitment-ideal-talent' },
        { title: 'Welfare Policy', href: '/recruitment-welfare-policy' },
        { title: 'Recruitment Pool Registration', href: '/recruitment-recruitment-pool-registration' }
      ]
    }
  ];

  const isActivePath = (href: string) => {
    if (href === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(href);
  };

  return (
    <>
      {/* Business Technology Header Banner */}
      <div className="h-20 bg-cover bg-center relative overflow-hidden" style={{
        backgroundImage: `url('/lovable-uploads/2ab2f56c-0833-44ac-bce1-8d35d2b4eb86.png')`,
        backgroundSize: '150% auto',
        backgroundPosition: 'left center',
        backgroundRepeat: 'repeat-x',
        imageRendering: 'crisp-edges'
      }}>
        <div className="absolute inset-0 bg-black/30"></div>
      </div>
      {/* Main Navigation Bar */}
      <header className="bg-white shadow-sm relative z-50 border-b border-gray-300">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-center items-center h-12 relative"> {/* Centered nav */}
            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center flex-1 justify-center"> {/* Center nav on desktop */}
              <div className="flex items-center justify-center w-full">
                {menuItems.map((item, index) => (
                  <div
                    key={item.title}
                    className="relative"
                    onMouseEnter={() => setActiveDropdown(item.title)}
                    onMouseLeave={() => setActiveDropdown(null)}
                  >
                    <Link
                      to={item.href}
                      className={`flex items-center space-x-1 px-4 py-3 text-xs font-bold transition-colors duration-200 border-r border-gray-300 ${
                        isActivePath(item.href)
                          ? 'text-black bg-gradient-to-b from-gray-200 to-gray-300 border-b-2 border-gray-400'
                          : 'text-gray-600 bg-gradient-to-b from-gray-100 to-gray-200 hover:from-gray-200 hover:to-gray-300'
                      } ${index === menuItems.length - 1 ? 'border-r-0' : ''}`}
                      style={{ 
                        fontFamily: 'Arial, sans-serif', 
                        fontSize: '11px', 
                        fontWeight: 'bold',
                        textShadow: '1px 1px 1px rgba(255,255,255,0.8)'
                      }}
                    >
                      <span className="uppercase tracking-wider">{item.title}</span>
                      {item.subItems.length > 0 && <ChevronDown className="w-3 h-3" />}
                    </Link>

                    {item.subItems.length > 0 && activeDropdown === item.title && (
                      <div className="absolute top-full left-0 mt-0 w-64 bg-white rounded-b-md shadow-lg border border-gray-200 py-2 z-50">
                        {item.subItems.map((subItem) => (
                          <Link
                            key={subItem.title}
                            to={subItem.href}
                            className={`block px-4 py-2 text-sm transition-colors duration-200 ${
                              location.pathname === subItem.href
                                ? 'text-[#1e5aa8] bg-blue-50 border-l-4 border-[#1e5aa8]'
                                : 'text-gray-700 hover:text-[#1e5aa8] hover:bg-gray-50'
                            }`}
                            style={{ fontFamily: 'Arial, sans-serif' }}
                          >
                            {subItem.title}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </nav>
            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-600 hover:bg-gray-100 transition-colors duration-200 mr-4 absolute right-0"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="lg:hidden bg-white border-t border-gray-300">
              <div className="px-2 pt-2 pb-3 space-y-1">
                {menuItems.map((item) => (
                  <div key={item.title}>
                    <Link
                      to={item.href}
                      className={`block px-3 py-2 rounded-md text-base font-medium transition-colors duration-200 ${
                        isActivePath(item.href)
                          ? 'text-black bg-gray-200'
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                      style={{ fontFamily: 'Arial, sans-serif' }}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <span className="uppercase tracking-wide">{item.title}</span>
                    </Link>
                    {item.subItems.length > 0 && (
                      <div className="ml-4 mt-1 space-y-1">
                        {item.subItems.map((subItem) => (
                          <Link
                            key={subItem.title}
                            to={subItem.href}
                            className={`block px-3 py-2 rounded-md text-sm transition-colors duration-200 ${
                              location.pathname === subItem.href
                                ? 'text-black bg-gray-200'
                                : 'text-gray-600 hover:text-black hover:bg-gray-100'
                            }`}
                            style={{ fontFamily: 'Arial, sans-serif' }}
                            onClick={() => setIsMenuOpen(false)}
                          >
                            {subItem.title}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </header>
    </>
  );
};

export default Header;
