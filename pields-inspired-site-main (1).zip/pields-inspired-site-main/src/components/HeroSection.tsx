
import React from "react";
import { Link } from "react-router-dom";
import { Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";

const HERO_IMAGE = "/lovable-uploads/6ccc1df5-73a4-4e60-b6f2-b9b5f2118fd2.png";
const YOUTUBE_VIDEO_ID = "6g9uegIUVx0";

const HeroSection = () => {
  return (
    <section
      className="w-full min-h-[600px] flex items-center justify-center relative overflow-hidden"
      style={{
        background: "linear-gradient(90deg, #1d3c78 0%, #3c68d7 60%, #7f4dd5 100%)",
        position: "relative",
        padding: "60px 0",
      }}
    >
      {/* YouTube video background */}
      <div
        className="absolute inset-0 z-0 pointer-events-none"
        aria-hidden="true"
        style={{
          width: "100%",
          height: "100%",
        }}
      >
        {/* Fallback image, only visible if iframe doesn't load */}
        <img
          src={HERO_IMAGE}
          alt=""
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "center",
            position: "absolute",
            inset: 0,
            zIndex: 0,
            opacity: 0.25,
            filter: "contrast(1.13) brightness(0.88) grayscale(0.36) blur(1.2px)",
          }}
        />
        {/* YouTube embed as background */}
        <iframe
          title="Hero Background Video"
          src={`https://www.youtube.com/embed/${YOUTUBE_VIDEO_ID}?autoplay=1&mute=1&controls=0&showinfo=0&loop=1&playlist=${YOUTUBE_VIDEO_ID}&modestbranding=1&rel=0&playsinline=1`}
          allow="autoplay; encrypted-media"
          allowFullScreen={false}
          frameBorder="0"
          className="w-full h-full"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "center",
            position: "absolute",
            inset: 0,
            zIndex: 1,
            opacity: 0.36,
            pointerEvents: "none",
            border: "none",
          }}
        />
      </div>
      {/* Semi-transparent subtle blue overlay for extra contrast */}
      <div
        className="absolute inset-0 z-10 pointer-events-none"
        style={{
          background: "rgba(29,60,120,0.16)",
        }}
      />
      <div className="relative z-20 flex flex-col items-center justify-center w-full max-w-3xl text-center mx-auto">
        <h1
          className="font-extrabold animate-fade-in-up"
          style={{
            fontFamily: "'Inter','Poppins',Arial,sans-serif",
            fontSize: 48,
            color: "#b5e5ff",
            textShadow: "0 4px 28px rgba(30, 65, 170, 0.29), 0 2px 5px rgba(10,16,38,0.12)",
            letterSpacing: "-0.01em",
            lineHeight: 1.08,
          }}
        >
          Best Engineers Inc
        </h1>
        <h2
          className="mt-4 font-medium animate-fade-in-up"
          style={{
            fontFamily: "'Inter','Poppins',Arial,sans-serif",
            fontSize: 20,
            color: "#fff",
            lineHeight: 1.6,
            fontWeight: 500,
            textShadow: "0 2px 14px rgba(0,0,0,0.23)",
            animationDelay: "0.06s",
          }}
        >
          Innovative engineering solutions for tomorrow’s industrial challenges.
        </h2>
        <div className="flex flex-wrap justify-center gap-x-3 gap-y-2 mt-7 animate-fade-in-up"
          style={{ animationDelay: "0.13s" }}
        >
          {["Innovation", "Excellence", "Sustainability"].map((tag) => (
            <span
              key={tag}
              style={{
                fontSize: 14,
                color: "#fff",
                background: "#475569",
                borderRadius: 25,
                padding: "6px 20px",
                fontWeight: 500,
                letterSpacing: "0.02em"
              }}
            >
              {tag}
            </span>
          ))}
        </div>
        {/* CTA */}
        <div className="mt-10 flex flex-col items-center gap-4 w-full animate-fade-in-up" style={{ animationDelay: "0.22s" }}>
          <Button
            asChild
            className="cta-btn flex items-center gap-2 px-[20px] py-[13px] text-[16px] rounded-[10px] font-semibold shadow-lg border-0"
            style={{
              background: "#fff",
              color: "#0b1c3a",
              boxShadow: "0 4px 10px rgba(0,0,0,0.10)",
              fontWeight: 600,
              minWidth: 120,
              maxWidth: 240
            }}
          >
            <Link to="/key-services" className="flex items-center gap-2 w-full h-full justify-center">
              <Rocket size={22} className="mr-2 opacity-90" />
              <span>Our Services</span>
            </Link>
          </Button>
        </div>
      </div>
      <style>{`
        @keyframes fade-in-up {
          0% {
            opacity: 0;
            transform: translateY(26px);
          }
          100% {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in-up {
          animation: fade-in-up 1.15s cubic-bezier(.23,1.1,.38,1) both;
        }
        .animate-fade-in-up[style*="animation-delay"] {
          animation-delay: var(--animation-delay, 0.1s) !important;
        }
      `}</style>
    </section>
  );
};

export default HeroSection;
